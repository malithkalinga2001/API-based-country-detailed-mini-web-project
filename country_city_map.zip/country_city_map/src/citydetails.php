
<!DOCTYPE html>

<?php
$Id=$_GET['ctId'];
$Name=$_GET['ctName'];
$state=$_GET['ctstate'];
$Cname=$_GET['ctCname'];
$countryCode=$_GET['Countrycode'];

$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => "https://city-and-state-search-api.p.rapidapi.com/search?q=$Id",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "X-RapidAPI-Host: city-and-state-search-api.p.rapidapi.com",
        "X-RapidAPI-Key: d7f8078cd1msh1fc3e4ee6c20e20p1f5a74jsn138171a9966e"
    ],
]);

$response = curl_exec($curl);
$error = curl_error($curl);

curl_close($curl);

if ($error) {
    echo "cURL Error #:" . $error;
} else {
    $c = json_decode($response, true);
}

?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>City Information</title>
        <link href="../css/layout.css" rel="stylesheet" />
        <link rel="stylesheet" 
              href="../bootstrap-5.0.2-dist/css/bootstrap.min.css" />
    
    
    </head>
    <body>
        <div id="main">
            <div id="header" class="bg bg-dark text text-white">Research and Development Lab </div>
            <div id="navigation" class="container-fluid"> <a class="l1" href="index.php">Home</a>&nbsp; <a class="l1" href="rest.php">RestFullWebService</a>&nbsp;<a class="l1" href="city.php">CitiesandStates</a></div>
            <div id="content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-1">&nbsp;</div>
                        <div class="col-md-10" >                           
                            <h4 class="ali">City Information </h4>               

                              <div class="container">

                                    <hr />

                                     <table class="table table-striped">

                                        <tr>
                                            <th>City ID : </th>
                                            <td><?php echo $Id; ?></td>
                                        </tr>
                                        <tr>
                                            <th>City Name :</th>
                                          <th><?php echo $Name; ?></th>
                                        </tr>
                                         <tr>
                                            <th>State Name : </th>
                                            <td><?php echo $state; ?></td>
                                        </tr>
                                         <tr>
                                            <th>Country Name :</th>
                                            <td><?php echo $Cname; ?></td>
                                        </tr>
                                        <tr>
                                             <th>Country Flag : </th>
                                            <th>
                                                <?php
                                                    echo "<img src='https://flagcdn.com/w320/" . strtolower($countryCode) . ".png' alt='" . $Name . " Flag' width='100' height='50'>";
                                                    ?>
                                            </th>
                                        </tr>
                                        <tr>
                                            <th colspan="2" style="text-align: center">
                                                <iframe width="100%" height="300" frameborder="1" style="border:1" referrerpolicy="no-referrer-when-downgrade" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyBLC1xERc-SwfAz4vb4sFhqB-KAHWRIT6I&q=<?php echo urlencode($Name . ', ' . $Cname); ?>&zoom=12"
                                                allowfullscreen>
                                                </iframe>
                                            </th>
                                        </tr>
                                    </table>
                                </div>
                        <div class="col-md-1">&nbsp;</div>
                        </div>
                    </div>                  
                </div>
                <div id="footer">
                    <div class="text text-dark">
                        All Right Received &copy;
                        2023                </div>    
                </div>
    </body>
</html>
