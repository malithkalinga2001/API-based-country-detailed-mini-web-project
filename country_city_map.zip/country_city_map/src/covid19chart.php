<?php
    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => "https://covid-193.p.rapidapi.com/statistics",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => [
            "X-RapidAPI-Host: covid-193.p.rapidapi.com",
            "X-RapidAPI-Key: d7f8078cd1msh1fc3e4ee6c20e20p1f5a74jsn138171a9966e"
        ],
    ]);

    $response = curl_exec($curl);
    $error = curl_error($curl);

    curl_close($curl);

    if ($error) {
        echo "Error occurred: " . $error;
        exit;
    }

    $data = json_decode($response, true);
	$c = $data['response'];
    //var_dump($c);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
        <title>COVID19 Information</title>
        <link href="../css/layout.css" rel="stylesheet" />
        <link rel="stylesheet" 
              href="../bootstrap-5.0.2-dist/css/bootstrap.min.css" />
    
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">

 
      google.charts.load('current', {'packages':['corechart']});

      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {


        var dataTable = new google.visualization.DataTable();
        dataTable.addColumn('string', 'Country');
        dataTable.addColumn('number', 'Cases');

        <?php
        foreach ($c as $v) {
            if ($v['continent'] == 'Europe' && $v['cases']['total'] <= 41000000) {

                $countryName = $v['country'];
                $cases = $v['cases']['total'];
            
                echo "dataTable.addRow(['$countryName', $cases]);";
            }
        }
        ?>
        
        var options = {
          title: 'Cases vs Countries in Europe',
          curveType: 'function',
          
            height: 500,
          legend: { position: 'bottom' }
        };

        
        var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
        chart.draw(dataTable, options);
      }
    </script>
	<style>
   .container-fluid{
	   text-align: right;
   }
   </style>
   
</head>
<body>
        <div id="main">
            <div id="header" class="bg bg-dark text text-white">Research and Development Lab </div>
            <div id="navigation" class="container-fluid"> <a class="l1" href="index.php">Home</a>&nbsp; <a class="l1" href="rest.php">RestFullWebService</a>&nbsp;<a class="l1" href="covid19.php">COVID19</a></div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-1">&nbsp;</div>
                        <div class="col-md-10" > 
                            <h4 class="ali">COVID19 Information in Europe - Bar Chart </h4>               
                            <div style="min-height: 500px;">
                                <div id="chart_div" ></div>
                            </div>
                            <div class="col-md-1">&nbsp;</div>
                        </div>
                    </div>                  
                </div>
            
        <div id="footer">
            <div class="text text-dark">
                    All Right Received &copy;
                    2023            
            </div>    
        </div>
        </div>
    </body>
</html>
