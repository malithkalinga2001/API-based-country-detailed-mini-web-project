
<!DOCTYPE html>
<?php
    $path="https://restcountries.com/v3.1/region/asia";

    $data=json_decode(file_get_contents($path),true);
    //var_dump($data[20]);
    $n=0;
    $no=0;
    $no2=0;
    $no3=0;
    $no4=0;
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Country Information</title>
        <link href="../css/layout.css" rel="stylesheet" />
        <link rel="stylesheet" 
              href="../bootstrap-5.0.2-dist/css/bootstrap.min.css" />
    
   
    </head>
    <body>
        <div id="main">
            <div id="header" class="bg bg-dark text text-white">Research and Development Lab </div>
            <div id="navigation" class="container-fluid"> <a class="l1" href="index.php">Home</a>&nbsp; <a class="l1" href="rest.php">RestFull Web Service</a></div>
            <div id="content">
                <h5 class="ali">Asian Countries </h5> 
                <div class="container">
                    
          
                        <table class="table table-striped">
                                <tr class="text text-primary">
                                    <th>Flag</th>
                                    <th>Country Name</th>
                                    <th>Capital City</th>
                                    <th>Region</th>
                                    <th>Subregion</th>
                                    <th>Currencies</th>
                                    <th>Country Code</th>
                                    <th>&nbsp;</th>

                                </tr> 
                            
                                <?php foreach($data as $v) { ?>   
                                <tr>
                                    <td><img src=<?php echo $v['flags']['png']?> alt='Flag' width="50px"/></td>
                                    <td><?php echo $v['name']['common']; ?></td>
                                    <td><?php
                                                if (isset($v['capital'][0])){
                                
                                                    $capital_city=$v['capital'][0];
                                                    echo $v['capital'][0];
                                                }
                                                else{
                                                    $capital_city=" ";
                                                }            
                                        ?>
                                    </td>
                                    <td><?php $b=$v['region']; echo $v['region']; ?></td>
                                    <td><?php echo $v['subregion']; ?></td>
                                    <td>
                                        <?php 
                                            
                                            $arrc=$data[$n]['currencies'];
                                            foreach($arrc as $p){
                                                    print($p['name']);
                                                    print("(".$p['symbol'].")");
                                               }
                                            $n=$n+1;
                                        ?>
                                    </td>
                                    <td><?php echo $v['cca2']; ?></td>
                                    <td>
                                       <a href="countrydetails.php?
                                                flag=<?php echo $v['flags']['png']; ?>&
                                                cname=<?php echo $v['name']['common']; ?>&
                                                cofficial=<?php echo $v['name']['official']; ?>&
                                                ccontinent=<?php echo $v['continents'][0]; ?>&
                                                clanguages=<?php 
                                                            $arrl=$data[$no]['languages'];
                                                            echo join(", ",$arrl);
                                                            $no=$no+1;
                                                            ?>&
                                                cborders=<?php 
                                                            if(isset($data[$no2]['borders'])){
                                                            $arrb=$data[$no2]['borders'];
                                                            echo join(", ",$arrb);
                                                            }
                                                            $no2=$no2+1;
                                                            ?>&
                                                cpopulation=<?php 
                                                            echo number_format($data[$no3]['population']);                       
                                                            $no3=$no3+1; 
                                                            ?>&
                                                carea=<?php 
                                                            echo number_format($data[$no4]['area']);                       
                                                            $no4=$no4+1; 
                                                            ?>&
                                                capital=<?php
                                                    if (isset($v['capital'][0])){

                                                        $capital_city=$v['capital'][0];
                                                        echo $v['capital'][0];
                                                    }
                                                    else{
                                                        $capital_city=" ";
                                                    }            
                                                    ?>&
                                                region=<?php echo $v['region']; ?>&
                                                currency=<?php print($p['name']); ?>&
                                                subregion=<?php echo $v['subregion']; ?>&
                                                
                                                
                                                ccode=<?php echo $v['cca2']; ?>"><button class="btn btn-success" type="button">View</button></a>
                                        <!--<a href="page2.php?param1=value1&param2=value2">-->
                                    </td>
                                </tr>
                                <?php } ?>
                        </table>   
                    </div>
                </div>  
            <div id="footer">
                <div class="text text-dark">
                    All Right Received &copy;
                    2023                </div>    
            </div>
        </div>
    </body>
</html>
