<?php
$cityInput = $_GET['q'];

$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => "https://city-and-state-search-api.p.rapidapi.com/cities/search?q=$cityInput",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "X-RapidAPI-Host: city-and-state-search-api.p.rapidapi.com",
        "X-RapidAPI-Key: d7f8078cd1msh1fc3e4ee6c20e20p1f5a74jsn138171a9966e"
    ],
]);

$response = curl_exec($curl);
$error = curl_error($curl);

curl_close($curl);

if ($error) {
    echo "cURL Error #:" . $error;
} else {
    $c = json_decode($response, true);
}
//var_dump($c[0]['country_code']);
?>

<html>
<head>
    <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="bootstrap-5.2.3/css/bootstrap.min.css"/>
    <title>City Details</title>
</head>

<body>
<div class="container">
    
    <table class="table table">
        <thead>
        <tr class= "text">
            <th>ID</th>
            <th>City Name</th>
            <th>State Name</th>
            <th>Country Name</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($c as $v) { ?>
            <tr>
                <td><?php echo $v['id']; ?></td>
                <td><?php echo $v['name']; ?></td>
                <td>
                    <?php 
                        if (isset($v['state_name'])) {
                            echo $v['state_name'];
                        }
                        else {
                            echo 'No data available';
                        }
                
                    ?>
                </td>
                <td>
                    <?php
                        if (isset($v['country_name'])) {
                            echo $v['country_name'];
                        }
                        else {
                            echo 'No data available';
                        }
                    ?>
            
                </td>
                <td><a href="citydetails.php?
                                    ctId=<?php echo $v['id']; ?>&
                                    ctName=<?php echo $v['name']; ?>&
                                    ctstate=<?php echo $v['state_name']; ?>&
                                    ctCname=<?php echo $v['country_name']; ?>&
                                    Countrycode=<?php echo $v['country_code']; ?>"><button type="button" class="btn btn-success">City Details</button>
                    </a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
</body>
</html>

