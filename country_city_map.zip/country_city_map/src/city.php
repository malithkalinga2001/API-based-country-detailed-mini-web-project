
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>City Information</title>
        <link href="../css/layout.css" rel="stylesheet" />
        <link rel="stylesheet" 
              href="../bootstrap-5.0.2-dist/css/bootstrap.min.css" />
    
     <script>
            function showCities(str) {
              var xhttp;
              if (str == "") {
                document.getElementById("show").innerHTML = "";
                return;
              }
              xhttp = new XMLHttpRequest();
              xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                document.getElementById("show").innerHTML = this.responseText;
                }
              };
              xhttp.open("GET", "getcities.php?q="+str, true);
              xhttp.send();
            }
            </script>
    </head>
    <body>
        <div id="main">
            <div id="header" class="bg bg-dark text text-white">Research and Development Lab </div>
            <div id="navigation" class="container-fluid"> <a class="l1" href="index.php">Home</a>&nbsp; <a class="l1" href="rest.php">RestFullWebService</a></div>
            <div id="content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-1">&nbsp;</div>
                        <div class="col-md-10" >                           
    <h5 class="ali">City Information </h5>               
 
      <div class="container">
            <h5 class="text text-primary">
                <div class="row">
                    <div class="col-md-4">Search Cities:</div>
                    <div class="col-md-8"> <input type="text" id="search" class="form-control" onkeyup="showCities(this.value)" />
               </div> </div>
            </h5>
            <hr />
            <div id="show">Load Cities</div>
            
        
   
        
   
   
                       </div>
                        <div class="col-md-1">&nbsp;</div>
                    </div>
                </div>                  
            </div>
            <div id="footer">
                <div class="text text-dark">
                    All Right Received &copy;
                    2023                </div>    
        </div>
    </body>
</html>
