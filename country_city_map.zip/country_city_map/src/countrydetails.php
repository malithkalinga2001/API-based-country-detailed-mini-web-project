
<!DOCTYPE html>
<?php
    $path="https://restcountries.com/v3.1/region/asia";

    $data=json_decode(file_get_contents($path),true);
    //var_dump($data[0]);
    
    $flag = $_GET['flag'];
    $cname = $_GET['cname'];
    $cofficial = $_GET['cofficial'];
    $ccontinent = $_GET['ccontinent'];
    $clanguages = $_GET['clanguages'];
    $cborders = $_GET['cborders'];
    $cpopulation = $_GET['cpopulation'];
    $carea = $_GET['carea'];
    $capital = $_GET['capital'];
    $region = $_GET['region'];
    $currency = $_GET['currency'];
    $subregion = $_GET['subregion'];
    $ccode = $_GET['ccode'];

?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Country Information</title>
        <link href="../css/layout.css" rel="stylesheet" />
        <link rel="stylesheet" 
              href="../bootstrap-5.0.2-dist/css/bootstrap.min.css" />
    
        
    <body>
        <div id="main">
            <div id="header" class="bg bg-dark text text-white">Research and Development Lab </div>
            <div id="navigation" class="container-fluid"> <a class="l1" href="index.php">Home</a>&nbsp; <a class="l1" href="rest.php">RestFull Web Service</a></div>
            <div id="content">
                <h3 class="ali"><?php echo $cname;?></h3> 
                <div class="container">
                    
          
                <div class="clearfix">&nbsp;</div>
                    <table class="table table-striped">
                        <tr>
                            <td colspan="2" style="text-align: center">
                                <img src=<?php echo $flag; ?> height="150px" />
                            </td>
                        </tr>

                        <tr>
                            <th>Official Name </th>
                          <th><?php echo $cofficial; ?></th>
                        </tr>
                         <tr>
                            <th>Capital </th>
                            <th><?php echo $capital; ?></th>
                        </tr>
                         <tr>
                            <th>Code </th>
                            <th><?php echo $ccode; ?></th>
                        </tr>
                        <tr>
                            <th>Currency </th>
                            <th><?php echo $currency; ?></th>
                        </tr>
                        <tr>
                            <th>Subregion </th>
                            <th><?php echo $subregion; ?></th>
                        </tr>
                         <tr>
                            <th>Continent </th>
                            <th><?php echo $ccontinent; ?></th>
                        </tr>
                        <tr>
                            <th>Languages </th>
                            <th><?php echo $clanguages; ?></th>
                        </tr>
                        <tr>
                            <th>Borders </th>
                            <th><?php echo $cborders; ?></th>
                        </tr>
                        <tr>
                            <th>Population </th>
                            <th><?php echo $cpopulation; ?></th>
                        </tr>
                        <tr>
                            <th>Area</th>
                            <th><?php echo $carea; ?></th>
                        </tr>

                    </table>  

  
                    </div>
                </div> 
            
            
            <div id="footer">
                <div class="text text-dark">
                    All Right Received &copy;
                    2023                </div>    
        </div>
            </div>
    </body>
</html>
