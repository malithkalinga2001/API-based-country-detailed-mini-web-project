<?php
    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => "https://covid-193.p.rapidapi.com/statistics",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => [
            "X-RapidAPI-Host: covid-193.p.rapidapi.com",
            "X-RapidAPI-Key: d7f8078cd1msh1fc3e4ee6c20e20p1f5a74jsn138171a9966e"
        ],
    ]);

    $response = curl_exec($curl);
    $error = curl_error($curl);

   curl_close($curl);

if ($error) {
    echo "cURL Error #:" . $error;
} else {
    $result = json_decode($response, true);
    $data = $result['response'];
}
?>

<html>
<head>
    <meta charset="UTF-8">
        <title>COVID19 Information</title>
        <link href="../css/layout.css" rel="stylesheet" />
        <link rel="stylesheet" 
              href="../bootstrap-5.0.2-dist/css/bootstrap.min.css" />
</head>
<body>
        <div id="main">
            <div id="header" class="bg bg-dark text text-white">Research and Development Lab </div>
            <div id="navigation" class="container-fluid"> <a class="l1" href="index.php">Home</a>&nbsp; <a class="l1" href="rest.php">RestFullWebService</a>&nbsp;<a class="l1" href="covid19.php">COVID19</a></div>
            <div id="content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-1">&nbsp;</div>
                        <div class="col-md-10" >                           
                            <h4 class="ali">COVID19 Information in Europe </h4>               

                            <div class="container">
                              <hr />
                                <table class="table">
                                    <tr>
                                        <th>Country</th>
                                        <th>Population</th>
                                        <th>Total COVID Cases</th>
                                        <th>Total Deaths</th>
                                        <th>Tests</th>
                                        <th>Continent</th>
                                    </tr>
                                <?php foreach ($data as $v) {
                                        if ($v['continent'] == "Europe") { ?>
                                        <tr>
                                            <td><?php echo $v['country']; ?></td>
                                            <td><?php echo $v['population'] ? $v['population'] : '0'; ?></td>
                                            <td><?php echo $v['cases']['total'] ? $v['cases']['total'] : '0'; ?></td>
                                            <td><?php echo $v['deaths']['total'] ? $v['deaths']['total'] : '0'; ?></td>
                                            <td><?php echo $v['tests']['total'] ? $v['tests']['total'] : '0'; ?></td>
                                            <td><?php echo $v['continent']; ?></td>
                                        </tr>
                                <?php }
                                } ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</body>
</html>
