<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
        <title>COVID19 Information Table</title>
        <link href="../css/layout.css" rel="stylesheet" />
        <link rel="stylesheet" href="../bootstrap-5.0.2-dist/css/bootstrap.min.css" />
</head>
<body>
    <div id="main">
        <div id="header" class="bg bg-dark text text-white">Research and Development Lab </div>
        <div id="navigation" class="container-fluid"> <a class="l1" href="index.php">Home</a>&nbsp; <a class="l1" href="rest.php">RestFull Web Service</a>&nbsp; <a class="l1" href="covid19.php">COVID19</a></div>
        <div id="content">
            <div class="container">
                <h4>This page only notify whether the data have been stored onto the database.</h4>
            </div>
        </div>
    </div>
</body>
</html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "covid2023";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_URL => "https://covid-193.p.rapidapi.com/statistics",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "X-RapidAPI-Host: covid-193.p.rapidapi.com",
        "X-RapidAPI-Key: d7f8078cd1msh1fc3e4ee6c20e20p1f5a74jsn138171a9966e"
    ],
]);
$response = curl_exec($curl);
$err = curl_error($curl);
curl_close($curl);
if ($err) {
    echo "cURL Error #:" . $err;
} else {
    $data = json_decode($response, true);
    $c = $data['response'];
}
foreach ($c as $v) {
	if ($v['continent'] == 'Europe') {
		$countryName = $v['country'];
		$population = $v['population'];
		$totalcases = $v['cases']['total'];
		$deaths = $v['deaths']['total'];
		$tests = $v['tests']['total'];
		$continent = $v['continent'];
		$date = $v['day'];
		$sql = "INSERT INTO covidcases (countryName, population, totalcases, deaths, tests, continent, date)
            VALUES ('$countryName', '$population', '$totalcases', '$deaths', '$tests', '$continent', '$date')";
    if ($conn->query($sql) === TRUE) {    
    } else {
        echo "Error: ";
    }
	}
}
echo '<script language="javascript">';
echo 'alert("Data Insertion is successful")';
echo '</script>';

$conn->close();
?>
